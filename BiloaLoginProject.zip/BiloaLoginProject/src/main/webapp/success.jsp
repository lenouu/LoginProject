<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Login Successful</title>
    <style>
        .row {
            margin: 1rem 0;
        }
        .success {
            color: green;
        }
    </style>
</head>
<body>
<h1 class="row success">LOGIN SUCCESSFUL</h1>
    <div style="padding:20px">
        <div class="row">
            <h3>Welcome! You have successfully logged in</h3>
        </div>
        <div class="row">
            <p>Thank you for using our application</p>
        </div>
    </div>
</body>
</html>