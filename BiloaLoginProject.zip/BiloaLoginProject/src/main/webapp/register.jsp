<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
    <title>User Registration</title>
    <style>
        .row {
            margin: 1rem 0;
        }
    </style>
</head>
<body>
    <h1 class="row">USER REGISTRATION</h1>
    <div style="padding:20px">
        <form action="RegisterServlet" method="post">
            <div class="row">
                <h3>Choose a username</h3>
                <input name="username" type="text" required>
            </div>
            <div class="row">
                <h3>Choose a password</h3>
                <input name="password" type="password" required>
            </div>
            <div class="row">
                <button type="submit">Register</button>
                <button type="reset">Reset</button>
            </div>
        </form>
        <div class="row">
            <p>Already have an account? <a href="login.jsp">Login here</a></p>
        </div>
    </div>
</body>
</html>