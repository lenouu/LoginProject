<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

<title>My Login page</title>
<style>
.row {
    margin: 1rem 0;
}
</style>
</head>

<body>
    <h1 class="row"> USER LOGIN </h1>
    <div style="padding:20px">
        <form action="LoginServlet" method="post">
            <div class="row">
                <h3>Enter your username</h3>
                <input name="username" type="text">
            </div>
            <div class="row">
                <h3>Enter your password</h3>
                <input name="password" type="password">
            </div>
            <div class="row">
                <button type="submit">Login</button>
                <button type="reset">Reset</button>
            </div>
        </form>
    </div>
</body>
</html>
