<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
 <title>Login Failed</title>
    <style>
        .row {
            margin: 1rem 0;
        }
        .error {
            color: red;
        }
        a {
            margin-right: 20px;
            text-decoration: none;
            padding: 8px 15px;
            background-color: #f0f0f0;
            border-radius: 5px;
        }
    </style>
</head>
<body>
<h1 class="row error"> LOGIN FAILED</h1>
    <div style="padding:20px">
        <div class="row">
            <h3>Invalid username or password</h3>
        </div>
        <div class="row">
            <p>Please try again or register as a new user.</p>
        </div>
        <div class="row">
	        <a href="login.jsp"> Try Login Again</a>
	        <a href="register.jsp"> Register New User</a>
        </div>
    </div>
</body>
</html>